<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8"/>
<title>Blog - Story Carry </title>
<meta name="title" content="Blog - Story Carry">
<meta name="description" content="Read & Write stories, life events in the language you wish for free. Hindi, Telugu, Tamil, English, Bengali, Marathi, Gujarati, Malayalam, Kannada, Punjabi, Russian, & ItaliaR">
<link rel="shortcut icon" href="<?php echo base_url();?>assets/landing/images/fav.png" type="image/x-icon" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:title" content="Blog - Story Carry">
<meta property="og:description" content="Read & Write stories, life events in the language you wish for free. Hindi, Telugu, Tamil, English, Bengali, Marathi, Gujarati, Malayalam, Kannada, Punjabi, Russian, & ItaliaR">
<meta property="og:url" content="https://storycarry.com/blogdetail">
<meta property="og:type" content="website">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/blog_detail.css">

</head>
<body>
<header>
    <font style="background: linear-gradient(to right, green 0%, #5658ae 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;margin-left:15px;color: white"><a href="<?php echo base_url();?>">StoryCarry.com</a></font>
    <font class="login-but"><a href="<?php echo base_url();?>">SIGN UP</a></font>
</header>
<div class="container1"> 
    <div class="content" >
        <?php if(isset($blogs) && ($blogs->num_rows() > 0)){ foreach($blogs->result() as $blog){ ?>
        <div style="background: white;padding: 10px;">   
            <div class="top-content">
                <font style="font-size:1.8em;line-height: 1.2em;"><?php echo $blog->caption;?></font>
                <div style="font-size:0.75em;margin-left:2px;margin-top: 10px;color:#676565;">
                    <i class="fa fa-clock-o" aria-hidden="true"></i> <font><?php echo substr($blog->created_at,0,10);?>.....</font>
                </div>
                <center>
                    <img src="<?php echo base_url().'assets/images/'.$blog->slideimage;?>" alt="BeingReader" class="main-image">
                </center>
            </div>
            <div class="down-content">
                <p>
                    <?php echo $blog->description;?>
                </p>
            </div>
        </div>
        
        <div class="content3" style="background:white; margin-top:45px;">
            <div class="comments">
                <form method="POST" action="#" style="margin-block-end:0px;">
                    <div class="editor" style="border-left:none; border-right:none;">
                        <div id="text" name="comment" class="editor-content" contenteditable></div>
                    </div>
                    <div class="insert-text" style="background:#f0f0f0;">
                        <span class="loading">POSTING...</span>
                        <span class="total-comment"></span>
                        <br>
                        <center>
                            <input type="hidden" name="blog_id" id="blog_id" value="<?php echo $blog->id;?>">
                            <!--<input type="submit" name="submit" id="submit" value="POST" style="width:80px;border:none;outline:none;background:rgb(60, 141, 188);color:white;padding:5px;cursor:pointer;" />-->
                            <button type="submit" name="submit" id="submit" style="width:80px;border:none;outline:none;background:rgb(60, 141, 188);color:white;padding:5px;cursor:pointer;">POST</button>
                        </center>
                    </div>
                </form>
            </div>
        </div>
        <?php } } ?>
        <?php if(isset($blogcomments) && ($blogcomments->num_rows() > 0)) { ?>
        <div class=""  id="loadmoreall" style="background: #f0f0f0;">
            <div class="list-comments">
                <?php foreach($blogcomments->result() as $blogcomment) { ?>
                    <div style="padding:10px;word-break:break-word;"><?php echo $blogcomment->comment; ?></div>
                <?php } ?>
            </div>
        </div>
        <div id="load_data_message"></div>
        <?php } ?>
    </div>
</div>

<div class="footer">
    <font style="float:left;font-size: 18px;margin-top: 8px;margin-left:10px;font-family: 'Varela Round', sans-serif;" class="copyright">
        Copyright <i class="fa fa-copyright" aria-hidden="true" style="font-size:12px;"></i> 2018 Being Reader
    </font>
    <div class="socialbtns">
        <font style="font-size:14px;color:black;font-family: 'Varela Round', sans-serif;" class="socialmedia">SOCIAL MEDIA : </font>
        <a href="" class="socialshare"><i class="fa fa-facebook-square hover-tems" aria-hidden="true" style="margin-right:8px"></i></a>
        <a href="" class="socialshare"><i class="fa fa-instagram hover-tems" aria-hidden="true" style="margin-right:6px"></i></a>
        <a href="" class="socialshare"><i class="fa fa-twitter-square hover-tems" aria-hidden="true" style="margin-right:6px"></i></a>
        <a href="" class="socialshare"><i class="fa fa-youtube-square hover-tems" aria-hidden="true"></i></a>
    </div>
</div>
<div class="footer1">
    <div style="font-size:14px;color:black;font-family: 'Varela Round', sans-serif;">
        <center>
            <font style="margin-right:10px" class="hover-tems"><a href="<?php echo base_url();?>about">ABOUT</a></font>
            <font style="margin-right:10px" class="hover-tems"><a href="<?php echo base_url();?>contact">CONTACT</a></font>
            <font style="margin-right:10px" class="hover-tems"><a href="<?php echo base_url();?>terms">TERMS</a></font>
            <font style="margin-right:10px" class="hover-tems"><a href="<?php echo base_url();?>privacy_policy">PRIVACY</a></font>
        </center>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    var $text = $("#text"),
    $submit = $("button[type='submit']"),
    $listComment = $(".list-comments"),
    $loading = $(".loading"),
    _data,
    $totalCom = $(".total-comment");
    $totalCom.text($(".list-comments > div").length);
    var blogid;
    $($submit).click(function() {
        blogid = $('#blog_id').val();
        if($text.html() === "") {
            alert("PLEASE ENTER COMMENT");
            $text.focus();
        } else {
            _data = $text.html();
            $.ajax({
                type: "POST",
                url: "<?php echo base_url();?>index.php/welcome/blog_comments",
                data: {'comment': _data, 'blogid':blogid},
                cache: false,
                success: function(data){
                    $loading.show().fadeOut(300);
                    $listComment.prepend("<div>"+_data+"</div>");
                    $text.html("");
                    $totalCom.text($(".list-comments > div").length);
                }
            });
            return false;
        }
    });
});
</script>
<script>
    $(document).ready(function(){
        var limit = 2;
        var start = 2;
        var action = 'inactive';
        
        function load_country_data(limit, start) {
            var blog_id = "<?php echo $blog->id; ?>";
            if(blog_id){
                $.ajax({
                    url:'<?php echo base_url();?>index.php/welcome/blogloadcomments',
                    method:"POST",
                    data:{limit:limit, start:start, blog_id: blog_id},
                    cache:false,
                    success:function(data){
                        $('#loadmoreall').append(data);
                        if(data == '') {
                            $('#load_data_message').html("<center> No More Results!</center>");
                            action = 'active';
                        }else{
                            $('#load_data_message').html("<center> Loading ...</center>");
                            action = "inactive";
                        }
                    }
                });
            }
        }
        if(action == 'inactive') {
            action = 'active';
            load_country_data(limit, start);
        } 
        $(window).scroll(function(){
            if($(window).scrollTop() + $(window).height() > $("#loadmoreall").height() && action == 'inactive'){
                action = 'active';
                start = start + limit;
                setTimeout(function(){load_country_data(limit, start);}, 500);
            }
        });
    });
</script>
</body>
</html>