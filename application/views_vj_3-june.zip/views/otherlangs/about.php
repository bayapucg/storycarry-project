<html lang="en">
<head>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8"/>
<title>About us - Story Carry </title>
<meta name="title" content="About us - Story Carry">
<meta name="description" content="Read & Write stories, life events in the language you wish for free. Hindi, Telugu, Tamil, English, Bengali, Marathi, Gujarati, Malayalam, Kannada, Punjabi, Russian, & ItaliaR">
<link rel="shortcut icon" href="<?php echo base_url();?>assets/landing/images/fav.png" type="image/x-icon" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:title" content="About us - Story Carry">
<meta property="og:description" content="Read & Write stories, life events in the language you wish for free. Hindi, Telugu, Tamil, English, Bengali, Marathi, Gujarati, Malayalam, Kannada, Punjabi, Russian, & ItaliaR">
<meta property="og:url" content="https://storycarry.com/about-us">
<meta property="og:type" content="website">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/about.css">
</head>
<body>
    <header>
        <span style="background: linear-gradient(to right, green 0%, #5658ae 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;margin-left:15px;color: white"><a href="<?php echo base_url();?>">StoryCarry.com</a></span>
        <span class="login-but"><a href="<?php echo base_url();?>">SIGN UP</a></span> 
    </header>

<div class="top-div"> 
  <div >
<h1 style="text-align:center;color:black;font-family:arial;" class="about">About Us</h1>
  </div>
<div class="intro-txt">We all have stories to tell and we don't want <br>stories to end, there are many ways to continue<br> stories and our platform is one of them.</div>
</div>
<div style="font-family: 'Muli', sans-serif; text-align: center">
        <h2 class="things">Things you can do in here</h2>
        </div>

<div class="sec-div">

 <div class="apps">
<div>
  <button style="background:linear-gradient(-60deg, RoyalBlue,aqua);" class="but"><i class="fas fa-book-reader fa-7x"></i>
  </button>
</div>
<font class="title">READ</font>
</div> 
  
  <div class="apps">
<div>
  <button style="background:linear-gradient(-60deg, yellow,red);" class="but"><i class="fas fa-pen-fancy fa-7x"></i>
  </button>
</div>
<font class="title">WRITE</font>
</div> 

<div class="apps">
<div>
  <button style="background:linear-gradient(-60deg, rgb(47, 68, 52),red);" class="but"><i class="fas fa-book fa-7x"></i>
 </button>
 </div>
 <font class="title">STORIES</font>
</div> 
    
    <div class="apps">
<div>
  <button style="background:linear-gradient(-60deg, green,pink);" class="but"><i class="fas fa-hiking fa-7x"></i>
  </button>
</div>
<font class="title">LIFE INCIDENTS</font>
</div> 
    
    <div class="apps">
<div>
  <button style="background:linear-gradient(-60deg, RoyalBlue,brown);" class="but"><i class="fas fa-eye-slash fa-7x"></i>
  </button>
</div>
<font class="title">BE ANONYMOUS</font>
</div> 
    
    <div class="apps">
<div>
  <button style="background:linear-gradient(-60deg, grey,aqua);" class="but"><i class="fas fa-users fa-7x"></i>
  </button>
</div>
<font class="title">CONNECT</font>
</div> 
    
    
    <div class="apps">
<div>
  <button style="background:linear-gradient(-45deg, brown,grey);" class="but"><i class="fas fa-coins fa-7x"></i>
  </button>
</div>
<font class="title">EARN</font>
</div> 
</div>

<div class="final-div"> 
 <div class="second-col">
<img src="<?php echo base_url();?>/assets/landing/aboutusimage.jpeg" class="col-img" alt="Indian online story writing" width="100%" height="100%">
</div>   

<div class="first-col">
  <h2>Our vision</h2>
  <font style="font-size: 1.3em;float: left;margin-bottom: 26px;"><span style="font-weight:bold;color: navy;"><i class="fas fa-quote-left"></i> No one else sees the world the way you do, so no one else can tell stories that you have to tell.</span><br><br> We aim to bring out those stories and life incidents from you and other 440 million Indians who are estimated to access Internet in next 2 years, by providing a language based reliable self-publishing platform.</font>
  <font style="font-size: 0.6em;">Quote by: Charles de Lint</font>
  </div>

</div>

<div class="footer">
    <font style="float:left;font-size: 18px;margin-top: 8px;margin-left:10px;font-family: 'Varela Round', sans-serif;" class="copyright">
        Copyright <i class="fa fa-copyright" aria-hidden="true" style="font-size:12px;"></i> 2018 Being Reader
    </font>
    <div class="socialbtns">
        <font style="font-size:14px;color:black;font-family: 'Varela Round', sans-serif;" class="socialmedia">SOCIAL MEDIA : </font>
        <a href="" class="socialshare"><i class="fa fa-facebook-square hover-tems" aria-hidden="true" style="margin-right:8px"></i></a>
        <a href="" class="socialshare"><i class="fa fa-instagram hover-tems" aria-hidden="true" style="margin-right:6px"></i></a>
        <a href="" class="socialshare"><i class="fa fa-twitter-square hover-tems" aria-hidden="true" style="margin-right:6px"></i></a>
        <a href="" class="socialshare"><i class="fa fa-youtube-square hover-tems" aria-hidden="true"></i></a>
    </div>
</div>
<div class="footer1">
    <div style="font-size:14px;color:black;font-family: 'Varela Round', sans-serif;">
        <center>
            <font style="margin-right:10px" class="hover-tems"><a href="<?php echo base_url();?>about">ABOUT</a></font>
            <font style="margin-right:10px" class="hover-tems"><a href="<?php echo base_url();?>contact">CONTACT</a></font>
            <font style="margin-right:10px" class="hover-tems"><a href="<?php echo base_url();?>terms">TERMS</a></font>
            <font style="margin-right:10px" class="hover-tems"><a href="<?php echo base_url();?>privacy_policy">PRIVACY</a></font>
        </center>
    </div>
</div>

</body>