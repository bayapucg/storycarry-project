<?php if(isset($storysuggesttogroup) && ($storysuggesttogroup->num_rows() == 1)){ 
    foreach($storysuggesttogroup->result() as $story){ ?>
    <div class="modal-header">
    	<button type="button" class="close" data-dismiss="modal" style="color:#000; opacity:initial; margin-top:2px;">&times;</button>
    	<h4 class="modal-title">
    	    <b><?php if(isset($this->session->userdata['logged_in']['name'])){
    	        //echo ucfirst($this->session->userdata['logged_in']['name']);
    	        }?></b> COMMUNITY SHARE 
    	        <!--<?php echo ucfirst($story->title);?>-->
    	</h4>
    </div>
    <div class="modal-body">
        <!--<h4> Read the following Story, it consists of some eye opening facts. </h4> -->
        <center><h5 class="resmsg"></h5></center>
    	<form id="storysuggestiontogroup">
    		<input type="hidden" name="title" value="<?php echo $story->title;?>">
    		<input type="hidden" name="sid" value="<?php echo $story->sid;?>">
    		<input type="hidden" name="image" value="<?php echo $story->image;?>">
    		<input type="hidden" name="story" value="<?php if($story->type == 'nano'){ echo $story->story; } else{ echo substr($story->story, 0,100); } ?>">
    	    <input type="hidden" name="type" value="<?php if($story->type == 'nano'){ echo 'story'; }else{ echo 'url'; } ?>">
    	    <input type="hidden" name="storywname" value="<?php if($story->type == 'nano'){ echo $story->name; } ?>">
    	    <input type="hidden" name="storywid" value="<?php if($story->type == 'nano'){ echo $story->user_id; } ?>">
    		<?php $openlinkurl = '#'; if($story->type == 'series'){ 
    		    $openlinkurl = $this->uri->segment(1).'/series/'.preg_replace('/\s+/', '-', $story->title).'-'.$story->sid.'/'.preg_replace('/\s+/', '-', $story->title).'-'.$story->story_id;
    		} elseif(($story->type == 'story') || ($story->type == 'life')){ 
    		    $openlinkurl = $this->uri->segment(1).'/story/'.preg_replace('/\s+/', '-', $story->title).'-'.$story->sid;
	        } else{ $openlinkurl = '#'; } ?>
    		<input type="hidden" name="url" value="<?php if($story->type != 'nano'){ echo base_url().$openlinkurl; } ?>">
    		<div class="row">
        		<div class="col-md-12">
            		<div class="input-group" style="display:block;">
            		    <input type="text" name="description" class="form-control" placeholder="Enter your text to post on community">
            		</div>
            	</div>
        	</div>
    		<br>
    		<div class="row">
    		    <div class="col-sm-12 user-block">
    		    
        		<?php if(isset($communities_gener) && ($communities_gener->num_rows() >0)){ ?>
        		    <select class="form-control" name="comm_id">
        		        <option value=""> -- Select Community to share Story --</option>
        		    <?php foreach($communities_gener->result() as $rowjoin) { ?>
        			    <option value="<?php echo $rowjoin->id; ?>"><?php echo ucfirst($rowjoin->gener);?></option>
        			    
        			    <!-- <input type="checkbox" name="comm_ids[]" value="<?php echo $rowjoin->id; ?>">
        			   <?php if(!empty($rowjoin->comm_image)){ ?>
        			         <img class="img-circle" src="<?php echo base_url();?>assets/images/<?php echo $rowjoin->comm_image;?>" style="float:none;margin-bottom:5px;">
        			    <?php }else{ ?>
        			        <img class="img-circle" src="<?php echo base_url();?>assets/images/2.png" style="float:none;margin-bottom:5px;">
        			    <?php } ?> 
        				<span><?php echo ucfirst($rowjoin->gener);?></span>-->
        			
            	    <?php } ?>
            	    </select>
            	<?php } ?>
            	
            	</div>
        	</div>
        <div class="modal-footer" style="padding-bottom:0px;padding-right: 0;">
            <button class="btn btn-primary pull-right" type="submit"> Send </button>
        </div>
    	</form>
    </div>
<?php } } else{ ?>
    <center> Something Wrong in Your Suggestion. Try Again. </center>
<?php } ?>

<script>
	$("form#storysuggestiontogroup").submit(function( event ) {
		event.preventDefault();
		$.post("<?php echo base_url().$this->uri->segment(1);?>/share_feed_communities",$("form#storysuggestiontogroup").serialize(),function(result) {
            if(result == 1){
                $('#snackbar').text('Story Shared on selected communities Successfully. ').addClass('show');
    			setTimeout(function(){ $('#snackbar').removeClass('show'); }, 4000);
    			setTimeout(function(){ $('#groupsuggest').modal('hide'); }, 2000);
            }else{
                $('#snackbar').text('Failed to share Story on communities. ').addClass('show');
    			setTimeout(function(){ $('#snackbar').removeClass('show'); }, 4000);
    			setTimeout(function(){ $('#groupsuggest').modal('hide'); }, 2000);
            }
		});
	});
</script>